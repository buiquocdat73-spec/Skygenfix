package manager;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.bukkit.Location;
import org.bukkit.block.Block;

import grassminevn.skygencore.Generator;
import grassminevn.skygencore.GeneratorDropState;
import grassminevn.skygencore.Main;
import storage.generator.generatorData;

public class generatorManager {
	private Main plugin;

	private Map<Location, Generator> gens;
	public static double radiusX;
	public static double radiusY;
	public static double radiusZ;
	
	public static HashMap<generatorData, GeneratorDropState> canDrop = new HashMap<>();

	public generatorManager(Main plugin) {
		gens = new HashMap<>();
		this.plugin = plugin;
	}

	public void addGenerator(generatorData data) {
		gens.put(data.getLocation(), new Generator(data));
		gens.get(data.getLocation()).runTaskTimer(plugin, 0, 20);
	}

	// So sánh toạ độ + thế giới, KHÔNG so pitch/yaw (Location.equals mặc định có so pitch/yaw
	// nên nếu generator được load lại từ file với pitch/yaw khác lúc đặt, containsKey(location)
	// sẽ luôn trả về false -> lệnh xoá generator bị no-op âm thầm, để lại armor stand/hologram
	// chạy mãi mãi. Đây chính là nguyên nhân entity bị rò rỉ gây lag server).
	private Location findMatchingGensKey(Location target) {
		for (Location loc : gens.keySet()) {
			if (loc.getWorld() != null && target.getWorld() != null
					&& loc.getWorld().equals(target.getWorld())
					&& loc.getBlockX() == target.getBlockX()
					&& loc.getBlockY() == target.getBlockY()
					&& loc.getBlockZ() == target.getBlockZ()) {
				return loc;
			}
		}
		return null;
	}

	public void removeGenerator(Block b) {

		for (Entry<String, generatorData> data : GENERATORdatabaseManager.data.entrySet()) {
			if (data.getValue().getLocation().getBlockX() == b.getLocation().getBlockX()
					&& data.getValue().getLocation().getBlockY() == b.getLocation().getBlockY()
					&& data.getValue().getLocation().getBlockZ() == b.getLocation().getBlockZ()) {
				// Luôn dọn hologram + xoá dữ liệu, không phụ thuộc vào việc có tìm thấy task đang chạy hay không
				hologramManager.deleteHologram(data.getValue());
				GENERATORdatabaseManager.delete(data.getKey());
			}
		}

		Location key = findMatchingGensKey(b.getLocation());
		if (key != null) {
			gens.get(key).cancel();
			gens.remove(key);
		}
	}
	
	public void removeGenerator(String generatorName) {
		
		if (!GENERATORdatabaseManager.data.containsKey(generatorName))
			return;
		
		generatorData data = GENERATORdatabaseManager.getData(generatorName);

		// Luôn dọn hologram/armor stand + xoá dữ liệu, kể cả khi không tìm thấy task runtime tương ứng
		hologramManager.deleteHologram(data);
		GENERATORdatabaseManager.delete(generatorName);

		Location key = findMatchingGensKey(data.getLocation());
		if (key != null) {
			gens.get(key).cancel();
			gens.remove(key);
		}
	}

	public boolean containsGenerator(Location location) {
		if (gens.containsKey(location))
			return true;
		return false;
	}

}
